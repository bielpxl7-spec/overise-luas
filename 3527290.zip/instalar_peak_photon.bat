@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion

echo ============================================
echo   PEAK - Photon Network Patch
echo   by OVERISE / token
echo ============================================
echo.

:: Detectar pasta do PEAK automaticamente via Steam
set "STEAM_PATHS=C:\Program Files (x86)\Steam\steamapps\common\PEAK C:\Program Files\Steam\steamapps\common\PEAK D:\Steam\steamapps\common\PEAK D:\SteamLibrary\steamapps\common\PEAK E:\Steam\steamapps\common\PEAK E:\SteamLibrary\steamapps\common\PEAK"

set "GAME_DIR="
for %%P in (%STEAM_PATHS%) do (
    if exist "%%P\PEAK.exe" (
        set "GAME_DIR=%%P"
    )
)

:: Tentar também pelo registro do Windows
if not defined GAME_DIR (
    for /f "tokens=2*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v "SteamPath" 2^>nul') do (
        set "STEAM_ROOT=%%B"
    )
    if defined STEAM_ROOT (
        set "STEAM_ROOT=!STEAM_ROOT:/=\!"
        if exist "!STEAM_ROOT!\steamapps\common\PEAK\PEAK.exe" (
            set "GAME_DIR=!STEAM_ROOT!\steamapps\common\PEAK"
        )
    )
)

:: Se não encontrou, pedir manualmente
if not defined GAME_DIR (
    echo [!] Pasta do PEAK nao encontrada automaticamente.
    echo.
    echo Digite o caminho completo da pasta do PEAK
    echo Exemplo: C:\Program Files (x86)\Steam\steamapps\common\PEAK
    echo.
    set /p "GAME_DIR=Caminho: "
    if not exist "!GAME_DIR!\PEAK.exe" (
        echo.
        echo [ERRO] PEAK.exe nao encontrado em: !GAME_DIR!
        echo Verifique o caminho e tente novamente.
        pause
        exit /b 1
    )
)

echo [OK] PEAK encontrado em:
echo      %GAME_DIR%
echo.

:: Destino do arquivo
set "DEST=%GAME_DIR%\PEAK_Data\resources.assets"

:: Verificar se ja esta patchado (backup existe)
if exist "%DEST%.original" (
    echo [INFO] Patch ja foi aplicado anteriormente.
    echo        Arquivo original salvo em: resources.assets.original
    echo.
    choice /C SN /M "Reaplicar o patch mesmo assim?"
    if errorlevel 2 goto :fim
)

:: URL do patch
set "PATCH_URL=https://github.com/bielpxl7-spec/overise-luas/releases/download/v1.0/resources.assets"

echo [*] Baixando resources.assets patchado...
echo     (37 MB - aguarde)
echo.

:: Fazer backup do original
if exist "%DEST%" (
    if not exist "%DEST%.original" (
        echo [*] Criando backup do original...
        copy /y "%DEST%" "%DEST%.original" >nul
        echo [OK] Backup salvo: resources.assets.original
    )
)

:: Download via PowerShell (mais confiavel que curl no Windows)
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $wc = New-Object System.Net.WebClient; $wc.DownloadFile('%PATCH_URL%', '%DEST%'); Write-Host '[OK] Download concluido.' } catch { Write-Host '[ERRO] Falha no download: ' + $_.Exception.Message; exit 1 }"

if errorlevel 1 (
    echo.
    echo [ERRO] Falha ao baixar o arquivo.
    echo Verifique sua conexao com a internet e tente novamente.
    if exist "%DEST%.original" (
        echo [*] Restaurando backup...
        copy /y "%DEST%.original" "%DEST%" >nul
    )
    pause
    exit /b 1
)

:: Verificar tamanho (deve ser ~39MB)
for %%F in ("%DEST%") do set "FSIZE=%%~zF"
if !FSIZE! LSS 30000000 (
    echo.
    echo [AVISO] Arquivo baixado parece incompleto (!FSIZE! bytes).
    echo         Esperado: ~39.000.000 bytes
    if exist "%DEST%.original" (
        echo [*] Restaurando backup...
        copy /y "%DEST%.original" "%DEST%" >nul
        echo [OK] Original restaurado. Tente novamente.
    )
    pause
    exit /b 1
)

echo.
echo ============================================
echo   PATCH APLICADO COM SUCESSO!
echo ============================================
echo.
echo   Arquivo: PEAK_Data\resources.assets
echo   Tamanho: !FSIZE! bytes
echo.
echo   O multiplayer Photon do PEAK esta pronto.
echo   Abra o jogo pelo OVERISE normalmente.
echo.
echo   Backup do original: resources.assets.original
echo ============================================
echo.

:fim
pause
exit /b 0
