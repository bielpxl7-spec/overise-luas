-- Generated with Luie @ https://lua.tools/
-- 4115450 - Phantom Blade Zero
-- Generated 2026-10-31 10:00:37 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(4115450, 1, "297a54d1db20c2d1e2c932dcf8c49f16933eec12e1dc20c8efb1d378c858e4c8")

-- Main Depots
addappid(4115451, 1, "44675a1e5068ae834e14eea59fc351cd0323eab43481ca5799d9720fd157a105")
-- setManifestid(4115451, "7450216563795868763", 150884679876)

-- DLC's (no depot keys required)
addappid(5041150) -- Phantom Blade Zero Deluxe Edition Upgrade
addappid(5068070) -- Phantom Blade Zero Pre-Purchase Bonus

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
