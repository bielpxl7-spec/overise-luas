addappid(5053820, 1, "Mimic Party")
addappid(5053821, 1, "Mimic Party")
setManifestid(5053821, "1188765496587361059")